from __future__ import annotations

import logging
from typing import Dict, List, Optional

from .config import Settings, get_settings
from .memory import SessionMemoryManager
from .model_loader import generate_with_confidence
from .prompts import BASE_PROMPT
from .retriever import PubMedRetriever
from .utils import (
    postprocess_answer,
    safe_json_loads,
    safety_guard,
    suppress_unmentioned_terms,
)

logger = logging.getLogger(__name__)


class MedAssistantPipeline:
    def __init__(self, settings: Settings | None = None):
        self.settings = settings or get_settings()
        self.retriever = PubMedRetriever(self.settings)
        self.memory_manager = SessionMemoryManager()

    def _filter_docs(self, docs: List[Dict], question: str) -> List[Dict]:
        if not docs:
            return []

        filtered = [
            d for d in docs if d.get("score", 0.0) >= self.settings.rag_score_threshold
        ]
        if not filtered:
            return []

        question_lower = question.lower()
        user_mentions_noise = any(
            keyword in question_lower for keyword in self.settings.noise_keywords
        )

        cleaned_docs = []
        for doc in filtered:
            text = f"{doc.get('title', '')} {doc.get('abstract', '')}".lower()
            doc_contains_noise = any(
                keyword in text for keyword in self.settings.noise_keywords
            )
            if doc_contains_noise and not user_mentions_noise:
                continue
            cleaned_docs.append(doc)

        return cleaned_docs

    def _build_context(self, docs: List[Dict]) -> str:
        if not docs:
            return "Không có tài liệu phù hợp trong PubMed."

        context_lines = []
        current_len = 0
        for idx, doc in enumerate(docs, 1):
            title = doc.get("title") or f"Bài {idx}"
            abstract = doc.get("abstract") or ""
            snippet = abstract[:1000]
            chunk = f"[{idx}] Title: {title}\nAbstract: {snippet}\nPMID: {doc.get('pmid', '')}\n"
            if current_len + len(chunk) > self.settings.max_context_chars:
                break
            context_lines.append(chunk)
            current_len += len(chunk)
        return "\n".join(context_lines)

    def ask(
        self,
        question: str,
        session_id: str = "default",
        *,
        max_new_tokens: Optional[int] = None,
        top_k: Optional[int] = None,
    ) -> Dict:
        """
        Pipeline xử lý câu hỏi theo LangChain pattern:
        1. Input: Nhận question + session_id
        2. Retrieve: Lấy lịch sử từ memory
        3. Inject: Đưa lịch sử vào prompt
        4. Generate: LLM trả lời
        5. Update: Lưu exchange vào memory
        """
        if not question or not question.strip():
            raise ValueError("Question must not be empty.")

        # Safety check
        warning = safety_guard(question) if self.settings.enable_safety_guard else None
        
        # Step 2: RETRIEVE - Lấy lịch sử từ memory
        history_text = self.memory_manager.get_history_text(session_id)
        recent_context = self.memory_manager.get_recent_context(session_id, max_exchanges=2)
        
        logger.info(f"[Pipeline] Question: {question[:100]}")
        logger.info(f"[Pipeline] Has history: {bool(recent_context)}")
        
        # RAG retrieval - dùng câu hỏi hiện tại kết hợp context gần nhất
        rag_docs = []
        context_text = "Không có tài liệu phù hợp."
        
        # Tạo query cho RAG: kết hợp câu hỏi hiện tại với context
        retrieval_query = question
        if recent_context:
            # Lấy câu hỏi trước đó từ recent_context để làm phong phú query
            prev_questions = [
                line.replace("Bệnh nhân:", "").strip()
                for line in recent_context.split("\n")
                if line.startswith("Bệnh nhân:")
            ]
            if prev_questions:
                # Ghép câu hỏi trước với câu hiện tại
                retrieval_query = f"{prev_questions[-1]}. {question}"
        
        if self.retriever.available:
            docs = self.retriever.retrieve(
                retrieval_query, top_k or self.settings.rag_top_k
            )
            rag_docs = self._filter_docs(docs, question)
            context_text = self._build_context(rag_docs)

        # Step 3: INJECT - Đưa lịch sử vào prompt
        prompt = BASE_PROMPT.format(
            history=history_text if history_text else "Chưa có lịch sử hội thoại.",
            context=context_text,
            question=question.strip(),
        )

        # Step 4: GENERATE - LLM xử lý
        draft, confidence = generate_with_confidence(
            prompt,
            max_new_tokens=max_new_tokens or self.settings.max_new_tokens,
            temperature=self.settings.temperature,
        )
        
        final_answer = postprocess_answer(draft)
        final_answer = suppress_unmentioned_terms(
            final_answer,
            f"{question}\n{context_text}",
            self.settings.cautious_terms,
        )
        verdict = "pass"
        citations: List[str] = []

        if warning:
            final_answer = f"{warning}\n\n{final_answer}"

        # Step 5: UPDATE - Lưu exchange vào memory (LangChain tự động)
        self.memory_manager.save_exchange(session_id, question, final_answer)

        return {
            "answer": final_answer,
            "draft": postprocess_answer(draft),
            "confidence": confidence,
            "verdict": verdict,
            "citations": citations,
            "context_docs": rag_docs,
            "warning": warning,
        }

